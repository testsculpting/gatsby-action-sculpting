---
title: Sculpting 主题配置说明文档 
tags: 文档,小书匠,sculpting
createDate: 2020-04-06
---


[toc!]

> Sculpting 主题是一款基本 Gatsbyjs 开发的博客主题,使用小书匠导出的 zip 做为数据源功能.

> 在短时间内就能创建一个自己的博客


## 主要功能

 - 基于 Gatsbyjs
 - 使用 Reactjs
 - 基于 Theme UI 主题配置
 - 支持代码块语法高亮
 - 响应式设计

## 快速搭建一个自己的 Github 博客

1. 直接 fork 一份 suziwen/gatsby-starter-sculpting
2. 使用小书匠编辑器,写一篇文章,然后导出为 zip 文件,放置在 posts 目录下,
3. 修改你 fork 仓库里,配置环境变量
4. 设置密钥变量
5. 设置 prefixpath 变量
6. 等待 actions 完成
7. 查看 xxx.github.io/xxxx 网址

更详细的图文介绍版本可以查看这篇文章

## 开始使用

本博客使用 Gatsby 进行开发,在开始使用 Sculpting 时,建议先了解下一此 Gatsby 的开发流程.

Gatsby 支持两种创建博客方式,一种是全新的安装模式,一种是在现有的 Gatsby 博客上进行扩展.

全新模式的安装后想要对主题进行修改的,可以直接修改相关的文件.扩展方式的安装,想要对主题进行微调的,需要使用到 Gatsby 的 shadowing component 功能,进行继承修改,详细教程可以参考 Gatsby 官方[教程](https://www.gatsbyjs.org/docs/themes/shadowing/)

## 全新模式安装

全新模式安装,可以更好的定制自己的主题.适合有 Gatsby 开发能力的用户

### 创建一个全新的博客


```
gatsby new suziwen/gatsby-starter-sculpting
```


## 扩展模式安装

如果你已经有了一个 Gatsbyjs 的静态网站,想在该网站的基础上安装 sculpting 主题,可以使用这种方式安装.

### 在现在 Gatsbyjs 的博客里添加新的子博客

```
npm install `@suziwen/gatsby-theme-sculpting`
```


``` javascript?title=gatsby-config.js
module.exports = {
  plugins: [ 'gatsby-theme-sculpting']
}
```


## 配置


### 主题颜色配置

可以创建一个主题专用的配置文件 `src/gatsby-plugin-theme-ui/index.js` 来修改主题样式的配置.


### 插件支持的参数

``` javascript?title=gatsby-config.js
module.exports = {
  plugins: [
    {
      resolve: 'gatsby-theme-sculpting',
      options: {
        basePath: 'blogs'
      }
  ]
}
```

### BasePath

### tagsPath

### archivesPath

### contentPath

放置小书匠 zip 文件的位置

### statistic

使用的统计, 目前支持 google anayly 和 baidu 这两家.

### 评论

目前支持 Disqus 和 Gitalk 这两家的评论系统

## 通用的 sitemetadata 配置

可以在 `gatsby-config.js` 里的 sitemetadata 节点,配置一些网站的基本信息.

### title

### idiom

### author


## 目录结构

```
├── gatsby-browser.js
├── gatsby-config.js // gatsby 默认的配置文件 
├── gatsby-node.js
├── gatsby-ssr.js
├── index.js
├── package.json
├── posts
│   └── 在这里存储小书匠导出的 zip 文件
├── README.md
├── src
│   ├── assets
│   ├── components //组件目录
│   ├── gatsby-plugin-theme-ui //样式主题
│   │   └── index.js
│   ├── header.mdx
│   ├── layouts //整个博客框架页面
│   │   ├── button.js
│   │   ├── footer.js
│   │   ├── header.js
│   │   ├── index.js
│   │   ├── menu-button.js
│   │   ├── nav-link.js
│   │   └── sidenav.js
│   ├── pages
│   │   ├── 404.js // 404 页面
│   │   ├── index-default.js //默认主页
│   │   └── search.js //搜索页面
│   ├── templates
│   │   ├── template-archive.js //归档模板
│   │   ├── template-blog-list.js //博客列表模板
│   │   ├── template-blog-post.js //博客文章模板
│   │   └── template-tag.js //标签模板
│   └── utils // 一些帮助函数
└── static // 静态引用的文件
```



